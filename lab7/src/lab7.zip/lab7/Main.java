package lab7;
 import java.io.*;

public class Main {


public static void serialize(int x) throws IOException 
	{
		Music s1 = new Music("Something Just Like This","Coldplay",400); 
		Music s2 = new Music("Shape of You","Ed Sheeran",350); 
		Music s3 = new Music("Despacito","Luis Fonsi",370);
		Music s4=new Music("Wild Thoughts","Rihanna",380);
		String s=Integer.toString(x);
		ObjectOutputStream out = null; 
		try {
              out = new ObjectOutputStream (
                    new FileOutputStream("./src/playlist"+s));
              out.writeObject(s1);
              out.writeObject(s2);
              out.writeObject(s3);
              out.writeObject(s4);
           	} finally {
              out.close();
           	}
	}

	public static void deserialize() throws IOException, ClassNotFoundException 
	{
		ObjectInputStream in = null;
		try 
		{
		    in =  new ObjectInputStream (
		           new FileInputStream("./src/playlist0"));
		    Music s1 = (Music) in.readObject();
		    
		    System.out.println(s1.getName());

		} 
		finally {
		    in.close();
		}
	}
//	public static void main(String[] args) throws IOException,ClassNotFoundException {
//		serialize(0);
//		deserialize();
//		
//
//	}
	
}